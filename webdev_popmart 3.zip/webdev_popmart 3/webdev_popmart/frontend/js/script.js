document.addEventListener('DOMContentLoaded', () => {
    // User Icon Dropdown Logic
    const userIcons = document.querySelectorAll('.user-icon');
    
    userIcons.forEach(icon => {
        // Prevent default link behavior if any
        const link = icon.querySelector('a');
        if (link) {
            link.addEventListener('click', (e) => {
                e.preventDefault();
            });
        }

        icon.addEventListener('click', (e) => {
            e.stopPropagation();
            const dropdown = icon.querySelector('.dropdown-menu');
            if (dropdown) {
                dropdown.classList.toggle('show');
            }
        });
    });

    // Close dropdowns when clicking outside
    document.addEventListener('click', () => {
        document.querySelectorAll('.dropdown-menu.show').forEach(dropdown => {
            dropdown.classList.remove('show');
        });
    });

    // Prevent closing when clicking inside the dropdown
    document.querySelectorAll('.dropdown-menu').forEach(dropdown => {
        dropdown.addEventListener('click', (e) => {
            e.stopPropagation();
        });
    });
});
