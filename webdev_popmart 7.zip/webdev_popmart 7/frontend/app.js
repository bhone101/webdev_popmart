const express = require('express');
const path = require('path');

const app = express();
const PORT = 3030;
const HOST = 'localhost';

// Middleware
app.use(express.static(path.join(__dirname, 'html')));
app.use(express.static(path.join(__dirname)));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'html', 'home.html'));
});

app.get('/detail', (req, res) => {
    res.sendFile(path.join(__dirname, 'html', 'detail.html'));
});

app.get('/search', (req, res) => {
    res.sendFile(path.join(__dirname, 'html', 'search.html'));
});

app.get('/advanced-search', (req, res) => {
    res.sendFile(path.join(__dirname, 'html', 'advanced_search.html'));
});

app.get('/team', (req, res) => {
    res.sendFile(path.join(__dirname, 'html', 'team.html'));
});

app.get('/admin-login', (req, res) => {
    res.sendFile(path.join(__dirname, 'html', 'admin_login.html'));
});

app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'html', 'admin.html'));
});

app.get('/product-management', (req, res) => {
    res.sendFile(path.join(__dirname, 'html', 'product_management.html'));
});

app.get('/add-product', (req, res) => {
    res.sendFile(path.join(__dirname, 'html', 'add_product.html'));
});

app.get('/edit-product', (req, res) => {
    res.sendFile(path.join(__dirname, 'html', 'edit_product.html'));
});

app.get('/delete-product', (req, res) => {
    res.sendFile(path.join(__dirname, 'html', 'delete_product.html'));
});

// 404 Error Handler - handles unknown routes
app.use((req, res) => {
    const timestamp = new Date().toISOString();
    console.error(`[${timestamp}] ERROR 404: Route "${req.path}" not found (${req.method} ${req.originalUrl})`);
    res.status(404).sendFile(path.join(__dirname, 'html', 'error.html'));
});

// Start server
app.listen(PORT, HOST, () => {
    console.log(`Server is running at http://${HOST}:${PORT}`);
});
